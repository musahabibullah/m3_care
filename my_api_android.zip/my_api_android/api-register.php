<?php

include 'koneksi.php';

// Ambil data dari form
$nama_lengkap = $_POST['nama_lengkap'];
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$nis = $_POST['nis'];
$telepon = $_POST['telepon'];
$kelas = $_POST['kelas']; // Tambahkan kelas
$tanggal_lahir = $_POST['tanggal_lahir'];

// Cek apakah semua field diisi
if (!empty($nama_lengkap) && !empty($username) && !empty($password) && !empty($email) && !empty($nis) && !empty($telepon) && !empty($kelas) && !empty($tanggal_lahir)) {
    // Query untuk cek apakah username sudah digunakan
    $queryCheck = "SELECT * FROM users WHERE username = '$username'";
    $resultCheck = mysqli_query($koneksi, $queryCheck);
    $rowCount = mysqli_num_rows($resultCheck);

    if ($rowCount == 0) {
        // Insert data ke tabel users
        $queryInsert = "INSERT INTO users (nama_lengkap, username, password, email, nis, telepon, kelas, tanggal_lahir)
                        VALUES ('$nama_lengkap', '$username', '$password', '$email', '$nis', '$telepon', '$kelas', '$tanggal_lahir')";

        $resultInsert = mysqli_query($koneksi, $queryInsert);

        if ($resultInsert) {
            echo "Daftar Berhasil";
        } else {
            echo "Gagal Mendaftar. Silakan coba lagi.";
        }
    } else {
        echo "Username Sudah Digunakan";
    }
} else {
    echo "Semua Data Harus Di Isi Lengkap";
}
?>
